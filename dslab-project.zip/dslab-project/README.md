# پروژه‌ی سایت آزمایشگاه علوم داده – دانشگاه فردوسی مشهد
# Data Science Lab website – Ferdowsi University of Mashhad

دو بخش / two parts:

1. `django-backend/` — **نسخه‌ی کامل با بک‌اند جنگو** (پنل مدیریت، پایگاه داده، فرم همکاری با ثبت در سرور). راه‌اندازی: `README.md` همان پوشه.
   The full site with the Django backend (admin panel, database, server-side application form). See its README.
2. `static-site/` — همان چهار صفحه‌ی دو زبانه به‌صورت فایل‌های ثابت (بدون سرور؛ فرم فقط شبیه‌سازی می‌شود و داده‌ها داخل فایل‌ها هستند).
   The same four bilingual pages as plain files (no server; the form is simulated, content lives inside the files).

صفحه‌ها / pages: خانه، اعضا، اطلاعیه‌ها و پروژه‌ها، همکاری با ما — فارسی و English.
