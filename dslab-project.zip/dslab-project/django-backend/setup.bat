@echo off
python -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
if not exist .env copy .env.example .env
python manage.py makemigrations lab
python manage.py migrate
python manage.py seed_content
echo Now create an admin user:
python manage.py createsuperuser
echo Run:  .venv\Scripts\activate ^&^& python manage.py runserver
