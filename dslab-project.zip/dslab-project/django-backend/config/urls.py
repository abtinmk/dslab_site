from django.conf import settings
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.static import serve

admin.site.site_header = "آزمایشگاه علوم داده – مدیریت"
admin.site.site_title = "مدیریت آزمایشگاه علوم داده"
admin.site.index_title = "مدیریت محتوای سایت"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("lab.urls")),
]

if settings.DEBUG or settings.SERVE_MEDIA:
    urlpatterns += [
        re_path(r"^media/(?P<path>.*)$", serve, {"document_root": settings.MEDIA_ROOT}),
    ]
