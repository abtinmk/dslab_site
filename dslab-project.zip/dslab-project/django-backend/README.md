# بک‌اند سایت آزمایشگاه علوم داده – دانشگاه فردوسی مشهد (Django)
# Backend for the Data Science Lab website (Django)

صفحه‌های دو زبانه (فارسی/English) همان فایل‌های قبلی‌اند که حالا قالب جنگو هستند و داده را از پایگاه داده می‌گیرند.
The bilingual pages are the earlier files, now Django templates fed from the database.

## راه‌اندازی سریع / Quick start

Linux / macOS:  `./setup.sh`      Windows: `setup.bat`

یا دستی / or manually:
```
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py makemigrations lab
python manage.py migrate
python manage.py seed_content        # اعضا + اطلاعیه و پروژه‌ی «نمونه» / members + SAMPLE news & projects
python manage.py createsuperuser
python manage.py runserver
```
- سایت / site: http://127.0.0.1:8000/
- پنل مدیریت / admin: http://127.0.0.1:8000/admin/

> `makemigrations lab` را فقط یک بار (قبل از `migrate`) اجرا کنید؛ پوشه‌ی `lab/migrations` را نگه دارید.
> Run `makemigrations lab` once before `migrate` and keep `lab/migrations/`.

## آدرس‌ها / URLs
| آدرس | کار |
|---|---|
| `/` `/members/` `/news/` `/apply/` | صفحه‌ها / pages |
| `POST /apply/submit/` | ثبت فرم همکاری (JSON) / application form |
| `/api/members/` `/api/announcements/` `/api/projects/` | داده‌ی JSON / read-only JSON |
| `/resume/<id>/` | دانلود رزومه (فقط مدیران) / résumé download (staff only) |
| `/admin/` | پنل مدیریت / admin |

## مدیریت محتوا از پنل / Managing content
- **اعضا**: افزودن/ویرایش، عکس، ترتیب، «نمایش در صفحه خانه» (۴ نفر اول خانه). / Members: add/edit, photo, order, "show on home".
- **اطلاعیه‌ها و پروژه‌ها**: هر مورد متن فارسی و انگلیسی دارد؛ لینک اختیاری است (آدرس کامل یا مسیر داخلی مثل `/apply/`). نشان «نمونه» را با برداشتن تیک «نمونه» حذف کنید. برچسب‌های پروژه با کاما جدا می‌شوند (انگلیسی به همان ترتیب فارسی).
- **درخواست‌های همکاری**: فهرست، فیلتر بر اساس وضعیت/موقعیت، تغییر وضعیت (جدید، در حال بررسی، پذیرفته، رد)، یادداشت مدیر، دانلود رزومه و خروجی CSV (عمل «خروجی CSV» بالای فهرست).
- اعداد صفحه‌ی خانه: «عضو» و «گروه» خودکار از پایگاه داده‌اند؛ «کشور» از `LAB_STATS_COUNTRIES` در `.env`.

## فرم همکاری / Application form
- اعتبارسنجی هم در مرورگر و هم در سرور؛ فقط PDF واقعی تا ۵ مگابایت (امضای `%PDF-` بررسی می‌شود).
- رزومه‌ها در پوشه‌ی `private/` ذخیره می‌شوند (نه در `media/`) و فقط از طریق پنل و برای مدیران قابل دانلودند.
- محافظت: توکن CSRF، فیلد مخفی ضدربات (honeypot) و سقف تعداد ثبت موفق از هر IP (پیش‌فرض ۵ در ساعت، `APPLY_RATE_LIMIT`).
- اگر `LAB_NOTIFY_EMAILS` را در `.env` بگذارید، با هر درخواست جدید ایمیل می‌آید. بدون تنظیم SMTP، ایمیل‌ها در ترمینال چاپ می‌شوند.

## پروداکشن / Production checklist
1. در `.env`: `DJANGO_DEBUG=0`، یک `DJANGO_SECRET_KEY` طولانی و تصادفی، `DJANGO_ALLOWED_HOSTS=دامنه`، و (پشت https) `DJANGO_CSRF_TRUSTED_ORIGINS=https://دامنه`.
2. `python manage.py collectstatic --noinput`
3. اجرا با gunicorn: `gunicorn config.wsgi` پشت nginx/Apache با HTTPS؛ پشت پروکسی `DJANGO_TRUST_PROXY=1`.
4. `media/` (عکس اعضا) را با وب‌سرور سرو کنید یا `DJANGO_SERVE_MEDIA` را روشن بگذارید. پوشه‌ی `private/` هرگز نباید عمومی شود.
5. در وب‌سرور حجم درخواست را حدود ۶ مگابایت محدود کنید (`client_max_body_size 6m;` در nginx).
6. از `db.sqlite3`، `media/` و `private/` پشتیبان بگیرید. برای بار زیاد، PostgreSQL در `DATABASES` تنظیم کنید.

## ساختار / Layout
```
config/            تنظیمات، URL اصلی / settings, root URLs
lab/models.py      Member, Announcement, Project, Application
lab/validation.py  اعتبارسنجی فرم (دو زبانه) / form validation (bilingual)
lab/serializers.py تبدیل مدل‌ها به JSON صفحه‌ها / model → page JSON
lab/views.py       صفحه‌ها، ثبت فرم، API / pages, form endpoint, API
lab/seed_data.py   داده‌ی اولیه / initial content
templates/site/    چهار صفحه‌ی دو زبانه (هر کدام یک فایل) / the four bilingual pages
```
- ترجمه‌ی متن‌های ثابت صفحه‌ها: آرایه‌ی `PAIRS` انتهای هر قالب (ردیف‌های `[فارسی, English]`).
- آزمون‌ها: `python manage.py test`
