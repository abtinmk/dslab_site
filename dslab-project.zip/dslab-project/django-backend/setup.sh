#!/usr/bin/env bash
set -e
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
python manage.py makemigrations lab
python manage.py migrate
python manage.py seed_content
echo "حالا مدیر بسازید / now create an admin user:"
python manage.py createsuperuser
echo "اجرا / run:  source .venv/bin/activate && python manage.py runserver"
