"""Stable codes for the application form: (code, فارسی, English)."""

LEVELS = [
    ("bachelor", "کارشناسی", "Bachelor’s"),
    ("master", "کارشناسی ارشد", "Master’s"),
    ("phd", "دکتری", "PhD"),
    ("graduate", "فارغ‌التحصیل / شاغل", "Graduate / employed"),
]
POSITIONS = [
    ("assistant", "دستیار پژوهشی", "Research assistant"),
    ("intern", "کارآموز", "Intern"),
    ("project", "همکاری پروژه‌ای", "Project-based"),
    ("postdoc", "پسادکتری", "Postdoc"),
]
AREAS = [
    ("ml", "یادگیری ماشین", "Machine learning"),
    ("nlp", "پردازش زبان طبیعی", "Natural language processing"),
    ("cv", "بینایی ماشین", "Computer vision"),
    ("bigdata", "داده‌های بزرگ", "Big data"),
    ("stats", "آمار و احتمال", "Statistics and probability"),
    ("viz", "مصورسازی داده", "Data visualization"),
]
HOURS = [
    ("lt10", "کمتر از ۱۰ ساعت", "Under 10 hours"),
    ("10_20", "۱۰ تا ۲۰ ساعت", "10–20 hours"),
    ("20_30", "۲۰ تا ۳۰ ساعت", "20–30 hours"),
    ("full", "تمام‌وقت", "Full-time"),
]


def as_choices(items):
    return [(code, fa) for code, fa, _en in items]


def codes(items):
    return {code for code, _fa, _en in items}
