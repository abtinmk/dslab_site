import csv

from django.contrib import admin
from django.http import HttpResponse
from django.urls import reverse
from django.utils.html import format_html

from .models import Announcement, Application, Member, Project


@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):
    list_display = ("name_fa", "name_en", "group", "order", "show_on_home", "is_active")
    list_editable = ("order", "show_on_home", "is_active")
    list_filter = ("group", "is_active", "show_on_home")
    search_fields = ("name_fa", "name_en", "affiliation_fa", "affiliation_en")
    fieldsets = (
        (None, {"fields": ("group", ("name_fa", "name_en"), "photo")}),
        ("مدرک و محل فعالیت", {"fields": (("degree_fa", "degree_en"), ("note_fa", "note_en"),
                                          ("affiliation_fa", "affiliation_en"))}),
        ("تماس", {"fields": ("email", "website")}),
        ("نمایش", {"fields": ("show_on_home", "order", "is_active")}),
    )


@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ("title_fa", "category", "date", "is_published", "is_sample")
    list_editable = ("is_published", "is_sample")
    list_filter = ("category", "is_published", "is_sample")
    search_fields = ("title_fa", "title_en", "text_fa", "text_en")
    date_hierarchy = "date"
    fieldsets = (
        (None, {"fields": (("date", "category"), ("title_fa", "title_en"), ("text_fa", "text_en"))}),
        ("لینک (اختیاری)", {"fields": ("link_url", ("link_label_fa", "link_label_en"))}),
        ("نمایش", {"fields": ("is_published", "is_sample")}),
    )


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("title_fa", "status", "order", "is_published", "is_sample")
    list_editable = ("order", "is_published", "is_sample")
    list_filter = ("status", "is_published", "is_sample")
    search_fields = ("title_fa", "title_en", "text_fa", "text_en", "tags_fa")
    fieldsets = (
        (None, {"fields": ("status", ("title_fa", "title_en"), ("text_fa", "text_en"),
                           ("tags_fa", "tags_en"))}),
        ("لینک (اختیاری)", {"fields": ("link_url", ("link_label_fa", "link_label_en"))}),
        ("نمایش", {"fields": ("order", "is_published", "is_sample")}),
    )


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "position", "level", "status", "created_at", "resume_link")
    list_filter = ("status", "position", "level", "hours", "created_at")
    search_fields = ("full_name", "email", "phone", "major", "skills", "message")
    date_hierarchy = "created_at"
    # فیلد resume عمداً در fields نیست: فایل خصوصی است و URL عمومی ندارد.
    fields = ("status", "admin_notes", "full_name", "email", "phone", "level", "major", "position",
              "areas_display", "hours", "skills", "github", "scholar", "message", "resume_link",
              "ip_address", "created_at")
    readonly_fields = ("full_name", "email", "phone", "level", "major", "position", "areas_display",
                       "hours", "skills", "github", "scholar", "message", "resume_link",
                       "ip_address", "created_at")
    actions = ("mark_reviewing", "mark_accepted", "mark_rejected", "export_csv")

    def has_add_permission(self, request):
        return False

    @admin.display(description="رزومه")
    def resume_link(self, obj):
        if not obj.pk or not obj.resume:
            return "-"
        return format_html('<a href="{}">دانلود PDF</a>', reverse("resume_download", args=[obj.pk]))

    @admin.display(description="حوزه‌ها")
    def areas_display(self, obj):
        return "، ".join(obj.areas_list())

    @admin.action(description="علامت‌گذاری: در حال بررسی")
    def mark_reviewing(self, request, queryset):
        queryset.update(status=Application.Status.REVIEWING)

    @admin.action(description="علامت‌گذاری: پذیرفته‌شده")
    def mark_accepted(self, request, queryset):
        queryset.update(status=Application.Status.ACCEPTED)

    @admin.action(description="علامت‌گذاری: ردشده")
    def mark_rejected(self, request, queryset):
        queryset.update(status=Application.Status.REJECTED)

    @admin.action(description="خروجی CSV (برای اکسل)")
    def export_csv(self, request, queryset):
        response = HttpResponse(content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = 'attachment; filename="applications.csv"'
        response.write("\ufeff")  # تا اکسل فارسی را درست نشان دهد
        w = csv.writer(response)
        w.writerow(["id", "created_at", "status", "full_name", "email", "phone", "level", "major",
                    "position", "areas", "hours", "skills", "github", "scholar", "message"])
        for a in queryset:
            w.writerow([a.pk, a.created_at.isoformat(), a.get_status_display(), a.full_name, a.email,
                        a.phone, a.get_level_display(), a.major, a.get_position_display(),
                        "، ".join(a.areas_list()), a.get_hours_display(), a.skills, a.github,
                        a.scholar, a.message])
        return response
