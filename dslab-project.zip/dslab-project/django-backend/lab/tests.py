import tempfile
from io import BytesIO

from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase, override_settings

from .models import Application


def _form(**over):
    data = {
        "fullName": "علی رضایی", "email": "ali@example.com", "phone": "09123456789",
        "level": "master", "major": "علوم کامپیوتر، دانشگاه فردوسی مشهد", "position": "assistant",
        "areas": ["ml", "nlp"], "hours": "10_20", "skills": "Python",
        "github": "https://github.com/ali", "scholar": "",
        "message": "من به یادگیری ماشین و پردازش متن فارسی علاقه دارم و می‌خواهم در پروژه‌های آزمایشگاه مشارکت کنم.",
        "consent": "on", "lang": "fa",
        "resume": SimpleUploadedFile("cv.pdf", b"%PDF-1.4\n%test\n", content_type="application/pdf"),
    }
    data.update(over)
    return data


class PagesTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_content", verbosity=0)

    def test_pages_render(self):
        for url in ("/", "/members/", "/news/", "/apply/"):
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_api(self):
        members = self.client.get("/api/members/").json()
        self.assertEqual(len(members), 23)
        self.assertEqual(members[0]["group"], "مسئول آزمایشگاه")
        self.assertTrue(self.client.get("/api/announcements/").json())
        self.assertTrue(self.client.get("/api/projects/").json())


class ApplyTest(TestCase):
    def test_valid_submission(self):
        r = self.client.post("/apply/submit/", _form())
        self.assertEqual(r.status_code, 200, r.content)
        self.assertTrue(r.json()["ok"])
        app = Application.objects.get()
        self.assertEqual(app.areas, "ml,nlp")
        self.assertTrue(app.resume.name.endswith(".pdf"))

    def test_errors_are_localized(self):
        r = self.client.post("/apply/submit/", _form(email="bad", lang="en"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("valid email", r.json()["errors"]["email"])
        self.assertEqual(Application.objects.count(), 0)

    def test_rejects_fake_pdf(self):
        fake = SimpleUploadedFile("cv.pdf", b"not a pdf at all", content_type="application/pdf")
        r = self.client.post("/apply/submit/", _form(resume=fake))
        self.assertIn("resume", r.json()["errors"])

    def test_honeypot(self):
        r = self.client.post("/apply/submit/", _form(company="spam"))
        self.assertTrue(r.json()["ok"])
        self.assertEqual(Application.objects.count(), 0)

    def test_resume_requires_staff(self):
        self.client.post("/apply/submit/", _form())
        pk = Application.objects.get().pk
        self.assertEqual(self.client.get("/resume/%d/" % pk).status_code, 302)
