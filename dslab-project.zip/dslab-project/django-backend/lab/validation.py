"""Server-side validation for the application form (mirrors the front-end rules).

Errors are returned as {field_name: message} in the visitor's language.
Pure Python (no Django imports) so it can be unit-tested on its own.
"""
import re
from urllib.parse import urlparse

from .choices import AREAS, HOURS, LEVELS, POSITIONS, codes

PHONE_RE = re.compile(r"^(\+98|0098|0)?9\d{9}$")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")
MAX_FILE = 5 * 1024 * 1024
MESSAGE_MIN, MESSAGE_MAX = 50, 1000
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def _url_ok(value):
    try:
        u = urlparse(value)
    except ValueError:
        return False
    return u.scheme in ("http", "https") and bool(u.netloc)


def validate_application(data, files, lang="fa"):
    """data: QueryDict-like (get/getlist). files: dict-like. Returns (errors, clean)."""
    en = lang == "en"

    def m(fa, e):
        return e if en else fa

    errors, clean = {}, {}

    def text(name, minlen, maxlen, fa, e):
        v = (data.get(name) or "").strip()
        if len(v) < minlen:
            errors[name] = m(fa, e)
        clean[name] = v[:maxlen]

    text("fullName", 3, 150, "نام و نام خانوادگی را کامل وارد کنید.", "Please enter your full name.")
    text("major", 3, 200, "رشته و دانشگاه را وارد کنید.", "Please enter your field and university.")

    email = (data.get("email") or "").strip()
    if not EMAIL_RE.match(email) or len(email) > 254:
        errors["email"] = m("ایمیل معتبر وارد کنید.", "Please enter a valid email address.")
    clean["email"] = email

    phone = (data.get("phone") or "").translate(_DIGITS)
    phone = re.sub(r"[\s-]", "", phone)
    if not PHONE_RE.match(phone):
        errors["phone"] = m("شماره موبایل معتبر وارد کنید، مثلاً 09123456789.",
                            "Please enter a valid mobile number, e.g. 09123456789.")
    clean["phone"] = phone

    level = data.get("level") or ""
    if level not in codes(LEVELS):
        errors["level"] = m("مقطع تحصیلی را انتخاب کنید.", "Please select your education level.")
    clean["level"] = level

    hours = data.get("hours") or ""
    if hours not in codes(HOURS):
        errors["hours"] = m("زمان در دسترس را انتخاب کنید.", "Please select your weekly availability.")
    clean["hours"] = hours

    position = data.get("position") or ""
    if position not in codes(POSITIONS):
        errors["position"] = m("یک موقعیت را انتخاب کنید.", "Please choose a position.")
    clean["position"] = position

    valid_areas = codes(AREAS)
    areas = []
    for a in data.getlist("areas"):
        if a in valid_areas and a not in areas:
            areas.append(a)
    if not areas:
        errors["areas"] = m("دست‌کم یک حوزه را انتخاب کنید.", "Please choose at least one area.")
    clean["areas"] = areas

    clean["skills"] = (data.get("skills") or "").strip()[:300]

    for name in ("github", "scholar"):
        v = (data.get(name) or "").strip()
        if v and (len(v) > 200 or not _url_ok(v)):
            errors[name] = m("نشانی معتبر وارد کنید، مثلاً https://github.com/username",
                             "Please enter a valid address, e.g. https://github.com/username")
        clean[name] = v

    message = (data.get("message") or "").strip()
    if len(message) < MESSAGE_MIN:
        errors["message"] = m("معرفی کوتاه باید حداقل ۵۰ نویسه باشد.",
                              "Your introduction must be at least 50 characters.")
    clean["message"] = message[:MESSAGE_MAX]

    if (data.get("consent") or "").lower() not in ("on", "true", "1", "yes"):
        errors["consent"] = m("برای ارسال، تأیید این بخش لازم است.", "You must confirm this to submit.")

    f = files.get("resume") if files is not None else None
    if f is None:
        errors["resume"] = m("رزومه را به‌صورت PDF بارگذاری کنید.", "Please upload your résumé as a PDF.")
    elif not (f.name or "").lower().endswith(".pdf"):
        errors["resume"] = m("فقط فایل PDF پذیرفته می‌شود.", "Only PDF files are accepted.")
    elif f.size > MAX_FILE:
        errors["resume"] = m("حجم فایل باید کمتر از ۵ مگابایت باشد.", "The file must be smaller than 5 MB.")
    else:
        head = f.read(5)
        f.seek(0)
        if head != b"%PDF-":
            errors["resume"] = m("فقط فایل PDF پذیرفته می‌شود.", "Only PDF files are accepted.")

    return errors, clean
