import uuid

from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.db import models
from django.utils import timezone

from .choices import AREAS, HOURS, LEVELS, POSITIONS, as_choices

GROUP_ORDER = ["head", "committee", "resident", "nonresident", "advisor"]


def get_private_storage():
    """رزومه‌ها خارج از MEDIA_ROOT ذخیره می‌شوند و هیچ URL عمومی ندارند."""
    return FileSystemStorage(location=str(settings.PRIVATE_ROOT))


def resume_upload_path(instance, filename):
    return "resumes/%s/%s.pdf" % (timezone.now().strftime("%Y/%m"), uuid.uuid4().hex)


class Member(models.Model):
    class Group(models.TextChoices):
        HEAD = "head", "مسئول آزمایشگاه"
        COMMITTEE = "committee", "کمیته علمی"
        RESIDENT = "resident", "همکاران مقیم"
        NONRESIDENT = "nonresident", "همکاران غیرمقیم"
        ADVISOR = "advisor", "مشاورین"

    group = models.CharField("گروه", max_length=20, choices=Group.choices, default=Group.RESIDENT)
    name_fa = models.CharField("نام (فارسی)", max_length=150)
    name_en = models.CharField("نام (انگلیسی)", max_length=150, blank=True)
    degree_fa = models.CharField("مدرک / سمت (فارسی)", max_length=200, blank=True)
    degree_en = models.CharField("مدرک / سمت (انگلیسی)", max_length=200, blank=True)
    note_fa = models.CharField("توضیح (فارسی)", max_length=300, blank=True)
    note_en = models.CharField("توضیح (انگلیسی)", max_length=300, blank=True)
    affiliation_fa = models.CharField("محل فعالیت (فارسی)", max_length=300, blank=True)
    affiliation_en = models.CharField("محل فعالیت (انگلیسی)", max_length=300, blank=True)
    email = models.EmailField("ایمیل", blank=True)
    website = models.URLField("صفحه شخصی", blank=True)
    photo = models.ImageField("عکس", upload_to="members/", blank=True)
    show_on_home = models.BooleanField("نمایش در صفحه خانه", default=False)
    order = models.PositiveIntegerField("ترتیب", default=0, help_text="عدد کوچک‌تر، بالاتر")
    is_active = models.BooleanField("فعال", default=True)

    class Meta:
        verbose_name = "عضو"
        verbose_name_plural = "اعضا"
        ordering = ["order", "id"]

    def __str__(self):
        return self.name_fa


class Announcement(models.Model):
    class Category(models.TextChoices):
        CALL = "call", "فراخوان"
        EVENT = "event", "رویداد"
        NEWS = "news", "خبر"

    date = models.DateField("تاریخ", default=timezone.localdate)
    category = models.CharField("دسته", max_length=10, choices=Category.choices, default=Category.NEWS)
    title_fa = models.CharField("عنوان (فارسی)", max_length=200)
    title_en = models.CharField("عنوان (انگلیسی)", max_length=200, blank=True)
    text_fa = models.TextField("متن (فارسی)")
    text_en = models.TextField("متن (انگلیسی)", blank=True)
    link_url = models.CharField("لینک", max_length=300, blank=True,
                                help_text="آدرس کامل (https://...) یا مسیر داخلی مثل /apply/")
    link_label_fa = models.CharField("متن دکمه (فارسی)", max_length=80, blank=True)
    link_label_en = models.CharField("متن دکمه (انگلیسی)", max_length=80, blank=True)
    is_published = models.BooleanField("منتشر شده", default=True)
    is_sample = models.BooleanField("نمونه (نشان «نمونه» نمایش داده شود)", default=False)

    class Meta:
        verbose_name = "اطلاعیه"
        verbose_name_plural = "اطلاعیه‌ها"
        ordering = ["-date", "-id"]

    def __str__(self):
        return self.title_fa


class Project(models.Model):
    class Status(models.TextChoices):
        ONGOING = "ongoing", "در حال انجام"
        DONE = "done", "تکمیل‌شده"

    status = models.CharField("وضعیت", max_length=10, choices=Status.choices, default=Status.ONGOING)
    title_fa = models.CharField("عنوان (فارسی)", max_length=200)
    title_en = models.CharField("عنوان (انگلیسی)", max_length=200, blank=True)
    text_fa = models.TextField("توضیح (فارسی)")
    text_en = models.TextField("توضیح (انگلیسی)", blank=True)
    tags_fa = models.CharField("برچسب‌ها (فارسی)", max_length=300, blank=True, help_text="با کاما جدا کنید")
    tags_en = models.CharField("برچسب‌ها (انگلیسی)", max_length=300, blank=True,
                               help_text="با کاما جدا کنید، به همان ترتیب برچسب‌های فارسی")
    link_url = models.CharField("لینک", max_length=300, blank=True)
    link_label_fa = models.CharField("متن دکمه (فارسی)", max_length=80, blank=True)
    link_label_en = models.CharField("متن دکمه (انگلیسی)", max_length=80, blank=True)
    order = models.PositiveIntegerField("ترتیب", default=0)
    is_published = models.BooleanField("منتشر شده", default=True)
    is_sample = models.BooleanField("نمونه (نشان «نمونه» نمایش داده شود)", default=False)

    class Meta:
        verbose_name = "پروژه"
        verbose_name_plural = "پروژه‌ها"
        ordering = ["order", "-id"]

    def __str__(self):
        return self.title_fa


class Application(models.Model):
    class Status(models.TextChoices):
        NEW = "new", "جدید"
        REVIEWING = "reviewing", "در حال بررسی"
        ACCEPTED = "accepted", "پذیرفته‌شده"
        REJECTED = "rejected", "ردشده"

    full_name = models.CharField("نام و نام خانوادگی", max_length=150)
    email = models.EmailField("ایمیل")
    phone = models.CharField("شماره تماس", max_length=20)
    level = models.CharField("مقطع تحصیلی", max_length=20, choices=as_choices(LEVELS))
    major = models.CharField("رشته و دانشگاه", max_length=200)
    position = models.CharField("موقعیت", max_length=20, choices=as_choices(POSITIONS))
    areas = models.CharField("حوزه‌ها", max_length=200, help_text="کدها با کاما جدا شده‌اند")
    hours = models.CharField("زمان در دسترس", max_length=10, choices=as_choices(HOURS))
    skills = models.CharField("مهارت‌ها", max_length=300, blank=True)
    github = models.URLField("گیت‌هاب / وب‌سایت", blank=True)
    scholar = models.URLField("گوگل اسکولار / ORCID", blank=True)
    resume = models.FileField("رزومه", storage=get_private_storage, upload_to=resume_upload_path)
    message = models.TextField("معرفی کوتاه")
    ip_address = models.GenericIPAddressField("IP", null=True, blank=True)
    status = models.CharField("وضعیت", max_length=12, choices=Status.choices, default=Status.NEW)
    admin_notes = models.TextField("یادداشت مدیر", blank=True)
    created_at = models.DateTimeField("زمان ثبت", auto_now_add=True)

    class Meta:
        verbose_name = "درخواست همکاری"
        verbose_name_plural = "درخواست‌های همکاری"
        ordering = ["-created_at"]

    def __str__(self):
        return "%s (%s)" % (self.full_name, self.email)

    def areas_list(self):
        labels = {c: fa for c, fa, _en in AREAS}
        return [labels.get(c, c) for c in self.areas.split(",") if c]
