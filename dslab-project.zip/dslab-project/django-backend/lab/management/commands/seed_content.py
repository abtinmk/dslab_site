from django.core.management.base import BaseCommand

from lab import seed_data
from lab.models import Announcement, Member, Project


class Command(BaseCommand):
    help = "بارگذاری داده‌ی اولیه (اعضا + اطلاعیه و پروژه‌ی نمونه). فقط جدول‌های خالی پر می‌شوند."

    def handle(self, *args, **options):
        for model, rows in ((Member, seed_data.MEMBERS),
                            (Announcement, seed_data.ANNOUNCEMENTS),
                            (Project, seed_data.PROJECTS)):
            if model.objects.exists():
                self.stdout.write("%s: already has data, skipped" % model.__name__)
                continue
            for i, row in enumerate(rows):
                extra = {"order": i} if model is Member else {}
                model.objects.create(**{**extra, **row})
            self.stdout.write(self.style.SUCCESS("%s: %d rows created" % (model.__name__, len(rows))))
