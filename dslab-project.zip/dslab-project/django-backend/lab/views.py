from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.core.cache import cache
from django.core.mail import send_mail
from django.http import FileResponse, Http404, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_GET, require_POST

from .models import GROUP_ORDER, Announcement, Application, Member, Project
from .serializers import announcement_data, member_data, project_data
from .validation import validate_application


def _members():
    rank = {g: i for i, g in enumerate(GROUP_ORDER)}
    items = list(Member.objects.filter(is_active=True))
    items.sort(key=lambda m: (rank.get(m.group, 99), m.order, m.pk))
    return items


def _announcements():
    return [announcement_data(a) for a in Announcement.objects.filter(is_published=True)]


def _projects():
    return [project_data(p) for p in Project.objects.filter(is_published=True)]


def _json(data):
    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})


# ---------------------------------------------------------------- pages ----
@require_GET
def home(request):
    members = _members()
    stats = {
        "members": len(members),
        "groups": len({m.group for m in members}),
        "countries": settings.LAB_STATS_COUNTRIES,
    }
    team = [member_data(m) for m in members if m.show_on_home]
    return render(request, "site/index.html", {"stats": stats, "team": team})


@require_GET
def members(request):
    return render(request, "site/members.html", {"members": [member_data(m) for m in _members()]})


@require_GET
def news(request):
    return render(request, "site/news.html",
                  {"announcements": _announcements(), "projects": _projects()})


@require_GET
def apply(request):
    return render(request, "site/apply.html")


# ------------------------------------------------------------ application ----
def _client_ip(request):
    if settings.TRUST_PROXY:
        fwd = request.META.get("HTTP_X_FORWARDED_FOR", "")
        if fwd:
            return fwd.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR") or None


@require_POST
def apply_submit(request):
    lang = "en" if request.POST.get("lang") == "en" else "fa"

    # honeypot: فیلد مخفی که فقط ربات‌ها پر می‌کنند
    if request.POST.get("company"):
        return JsonResponse({"ok": True})

    ip = _client_ip(request)
    limit, window = settings.APPLY_RATE_LIMIT
    cache_key = "dslab-apply:%s" % (ip or "unknown")
    if cache.get(cache_key, 0) >= limit:
        msg = ("تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید." if lang == "fa"
               else "Too many applications; please try again later.")
        return JsonResponse({"ok": False, "errors": {"__all__": msg}}, status=429)

    errors, c = validate_application(request.POST, request.FILES, lang)
    if errors:
        return JsonResponse({"ok": False, "errors": errors}, status=400)

    app = Application(
        full_name=c["fullName"], email=c["email"], phone=c["phone"], level=c["level"],
        major=c["major"], position=c["position"], areas=",".join(c["areas"]),
        hours=c["hours"], skills=c["skills"], github=c["github"], scholar=c["scholar"],
        message=c["message"], ip_address=ip,
    )
    app.resume = request.FILES["resume"]
    app.save()

    cache.add(cache_key, 0, window)
    try:
        cache.incr(cache_key)
    except ValueError:
        cache.set(cache_key, 1, window)

    if settings.LAB_NOTIFY_EMAILS:
        send_mail(
            "درخواست همکاری جدید: %s" % app.full_name,
            "نام: %s\nایمیل: %s\nموقعیت: %s\nحوزه‌ها: %s\n\nمشاهده در پنل مدیریت: /admin/lab/application/%s/change/"
            % (app.full_name, app.email, app.get_position_display(), "، ".join(app.areas_list()), app.pk),
            settings.DEFAULT_FROM_EMAIL,
            settings.LAB_NOTIFY_EMAILS,
            fail_silently=True,
        )
    return JsonResponse({"ok": True})


@staff_member_required
def resume_download(request, pk):
    app = get_object_or_404(Application, pk=pk)
    if not app.resume:
        raise Http404
    try:
        fh = app.resume.open("rb")
    except (FileNotFoundError, OSError):
        raise Http404
    return FileResponse(fh, as_attachment=True, filename="resume-%s.pdf" % app.pk,
                        content_type="application/pdf")


# -------------------------------------------------------------- JSON API ----
@require_GET
def api_members(request):
    return _json([member_data(m) for m in _members()])


@require_GET
def api_announcements(request):
    return _json(_announcements())


@require_GET
def api_projects(request):
    return _json(_projects())
