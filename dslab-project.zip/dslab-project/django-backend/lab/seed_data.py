# -*- coding: utf-8 -*-
"""Initial content: real members (from the lab's current site) + SAMPLE announcements/projects."""

FUM = ("دانشگاه فردوسی مشهد", "Ferdowsi University of Mashhad")
STAT = ("دکتری آمار", "PhD in Statistics")
AMATH = ("دکتری ریاضی کاربردی", "PhD in Applied Mathematics")
CS = ("دکتری کامپیوتر", "PhD in Computer Science")
PMATH = ("دکتری ریاضی محض", "PhD in Pure Mathematics")
NONE = ("", "")


def _m(group, fa, en, deg, note=NONE, aff=FUM, home=False):
    return dict(group=group, name_fa=fa, name_en=en, degree_fa=deg[0], degree_en=deg[1],
                note_fa=note[0], note_en=note[1], affiliation_fa=aff[0], affiliation_en=aff[1],
                show_on_home=home)


MEMBERS = [
    _m("head", "محمد آرشی", "Mohammad Arashi", STAT,
       ("مسئول آزمایشگاه و دبیر کمیته علمی", "Lab Head and Secretary of the Scientific Committee"), home=True),
    _m("committee", "آرزو حبیبی راد", "Arezoo Habibi Rad", STAT, home=True),
    _m("committee", "جاهد نقی پور", "Jahed Naghipoor", AMATH, ("Research Fellow", "Research Fellow"),
       ("Alexander von Humboldt Foundation, Germany", "Alexander von Humboldt Foundation, Germany"), home=True),
    _m("committee", "امید سلیمانی فرد", "Omid Soleimani Fard", AMATH, home=True),
    _m("committee", "مسعود مظلوم", "Masoud Mazloom", CS, NONE,
       ("Informatics Institute, University of Amsterdam, The Netherlands",
        "Informatics Institute, University of Amsterdam, The Netherlands")),
    _m("resident", "محمد امینی", "Mohammad Amini", STAT),
    _m("resident", "هادی جباری", "Hadi Jabbari", STAT),
    _m("resident", "علیرضا سهیلی", "Alireza Soheili", AMATH),
    _m("resident", "مهدی دوست پرست", "Mehdi Doostparast", STAT),
    _m("resident", "مصطفی رزمخواه", "Mostafa Razmkhah", STAT),
    _m("resident", "رسول رمضانیان", "Rasoul Ramezanian", CS),
    _m("resident", "مجید سرمد", "Majid Sarmad", STAT),
    _m("resident", "کاظم خشیارمنش", "Kazem Khashyarmanesh", PMATH),
    _m("resident", "مرتضی گچ پزان", "Morteza Gachpazan", AMATH),
    _m("resident", "سهراب عفتی", "Sohrab Effati", AMATH),
    _m("resident", "اصغر قربانی", "Asghar Ghorbani", AMATH),
    _m("resident", "رضا قنبری", "Reza Ghanbari", AMATH),
    _m("resident", "رضا منصفی", "Reza Monsefi", CS),
    _m("resident", "Dr. Hashem Salarzadeh Jenatabadi", "Dr. Hashem Salarzadeh Jenatabadi",
       ("Senior Lecturer", "Senior Lecturer"),
       ("Department of Science and Technology Studies, Faculty of Science",) * 2,
       ("University of Malaya (UM), 50603 Kuala Lumpur, Malaysia",) * 2),
    _m("nonresident", "مرتضی امینی", "Morteza Amini", STAT,
       ("دبیر هسته پژوهشی یادگیری ماشین و پردازش سیگنال",
        "Secretary, Machine Learning and Signal Processing Research Core"),
       ("دانشگاه تهران", "University of Tehran")),
    _m("nonresident", "علی دولتی", "Ali Dolati", STAT, NONE, ("دانشگاه یزد", "Yazd University")),
    _m("nonresident", "مهدی صالحی", "Mehdi Salehi", STAT, NONE, ("دانشگاه نیشابور", "Neyshabur University")),
    _m("advisor", "وحید پرتوی نیا", "Vahid Partovi Nia", STAT,
       ("Adjunct Professor, Polytechnique Montréal, Canada; Principal Machine Learning Scientist, Huawei Noah's Ark Lab",) * 2,
       NONE),
]

# موارد نمونه: is_sample=True تا نشان «نمونه» نمایش داده شود. از پنل مدیریت ویرایش یا حذف کنید.
ANNOUNCEMENTS = [
    dict(date="2026-11-10", category="call", is_sample=True,
         title_fa="فراخوان جذب دستیار پژوهشی", title_en="Call for research assistants",
         text_fa="دانشجویان علاقه‌مند به آمار، یادگیری ماشین و تحلیل داده می‌توانند از طریق فرم درخواست همکاری اقدام کنند.",
         text_en="Students interested in statistics, machine learning and data analysis can apply through the application form.",
         link_url="/apply/", link_label_fa="ارسال درخواست", link_label_en="Submit application"),
    dict(date="2026-11-03", category="event", is_sample=True,
         title_fa="جلسه‌ی معرفی آزمایشگاه", title_en="Lab introduction session",
         text_fa="جلسه‌ای برای معرفی فعالیت‌ها و پروژه‌های آزمایشگاه به دانشجویان جدید.",
         text_en="A session introducing the lab’s activities and projects to new students."),
    dict(date="2026-10-20", category="news", is_sample=True,
         title_fa="پیوستن همکاران جدید به تیم", title_en="New collaborators join the team",
         text_fa="فهرست به‌روز اعضا و همکاران آزمایشگاه در صفحه‌ی اعضا در دسترس است.",
         text_en="The updated list of lab members and collaborators is available on the Members page.",
         link_url="/members/", link_label_fa="اعضای آزمایشگاه", link_label_en="Lab members"),
    dict(date="2026-10-05", category="event", is_sample=True,
         title_fa="کارگاه آموزشی تحلیل داده", title_en="Data analysis workshop",
         text_fa="کارگاهی کاربردی درباره‌ی تحلیل و مصورسازی داده برای دانشجویان تحصیلات تکمیلی.",
         text_en="A hands-on workshop on data analysis and visualization for graduate students."),
]

PROJECTS = [
    dict(status="ongoing", is_sample=True, order=1,
         title_fa="پردازش متن فارسی", title_en="Persian text processing",
         text_fa="ساخت و ارزیابی مدل‌های یادگیری ماشین برای دسته‌بندی و تحلیل متن فارسی.",
         text_en="Building and evaluating machine learning models for classifying and analyzing Persian text.",
         tags_fa="پردازش زبان طبیعی, یادگیری ماشین", tags_en="Natural language processing, Machine learning"),
    dict(status="done", is_sample=True, order=2,
         title_fa="پیش‌بینی سری‌های زمانی", title_en="Time-series forecasting",
         text_fa="مقایسه‌ی روش‌های آماری و یادگیری ماشین برای پیش‌بینی داده‌های زمانی.",
         text_en="Comparing statistical and machine learning methods for forecasting time-dependent data.",
         tags_fa="آمار و مدل‌سازی, سری زمانی", tags_en="Statistics and modeling, Time series"),
    dict(status="ongoing", is_sample=True, order=3,
         title_fa="داشبورد داده‌های آماری", title_en="Statistical data dashboard",
         text_fa="طراحی داشبوردی تعاملی برای نمایش و کاوش مجموعه‌داده‌های آماری.",
         text_en="Designing an interactive dashboard for presenting and exploring statistical datasets.",
         tags_fa="مصورسازی داده, آمار و مدل‌سازی", tags_en="Data visualization, Statistics and modeling"),
    dict(status="done", is_sample=True, order=4,
         title_fa="تشخیص ناهنجاری در سیگنال‌ها", title_en="Anomaly detection in signals",
         text_fa="شناسایی الگوهای غیرعادی در سیگنال‌های حسگر با روش‌های آماری.",
         text_en="Identifying unusual patterns in sensor signals using statistical methods.",
         tags_fa="پردازش سیگنال, تشخیص ناهنجاری", tags_en="Signal processing, Anomaly detection"),
]
