from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("members/", views.members, name="members"),
    path("news/", views.news, name="news"),
    path("apply/", views.apply, name="apply"),
    path("apply/submit/", views.apply_submit, name="apply_submit"),
    path("resume/<int:pk>/", views.resume_download, name="resume_download"),
    path("api/members/", views.api_members, name="api_members"),
    path("api/announcements/", views.api_announcements, name="api_announcements"),
    path("api/projects/", views.api_projects, name="api_projects"),
]
