"""Turn model instances into the JSON shapes the front-end pages expect."""


def _pair(fa, en):
    return [fa, en or fa]


def split_tags(value):
    return [x.strip() for x in (value or "").replace("،", ",").split(",") if x.strip()]


def member_data(m):
    return {
        "name": m.name_fa,
        "en": m.name_en or "",
        "group": m.get_group_display(),  # برچسب فارسی گروه؛ سمت صفحه ترجمه‌اش می‌کند
        "role": m.degree_fa,
        "roleEn": m.degree_en,
        "note": m.note_fa,
        "noteEn": m.note_en,
        "affil": m.affiliation_fa,
        "affilEn": m.affiliation_en,
        "email": m.email,
        "site": m.website,
        "photo": m.photo.url if m.photo else "",
    }


def _link(obj):
    if not obj.link_url:
        return None
    return {"href": obj.link_url, "label": _pair(obj.link_label_fa or obj.link_url, obj.link_label_en)}


def announcement_data(a):
    return {
        "date": a.date.isoformat(),
        "cat": a.category,
        "sample": a.is_sample,
        "title": _pair(a.title_fa, a.title_en),
        "text": _pair(a.text_fa, a.text_en),
        "link": _link(a),
    }


def project_data(p):
    fa, en = split_tags(p.tags_fa), split_tags(p.tags_en)
    return {
        "status": p.status,
        "sample": p.is_sample,
        "tags": [_pair(t, en[i] if i < len(en) else "") for i, t in enumerate(fa)],
        "title": _pair(p.title_fa, p.title_en),
        "text": _pair(p.text_fa, p.text_en),
        "link": _link(p),
    }
