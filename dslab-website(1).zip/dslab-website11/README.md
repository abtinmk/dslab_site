# سایت آزمایشگاه علوم داده – دانشگاه فردوسی مشهد
# Data Science Lab – Ferdowsi University of Mashhad (bilingual FA / EN)

هر صفحه یک فایل مستقل است (HTML + CSS + JS) / Each page is one self-contained file:

- `index.html`   خانه / Home
- `members.html` اعضا / Members  (داده‌ها در آرایه‌ی `MEMBERS` / data in the `MEMBERS` array)
- `news.html`    اطلاعیه‌ها و پروژه‌ها / News & Projects  (آرایه‌های `ANNOUNCEMENTS` و `PROJECTS`)
- `apply.html`   درخواست همکاری / Apply (اتصال به بک‌اند: `TODO` در بخش script / backend hook: `TODO` in script)

برای اجرا هر چهار فایل را کنار هم نگه دارید و `index.html` را باز کنید.
Keep the four files together and open `index.html`.

## اطلاعیه‌ها و پروژه‌ها / News & Projects
- موارد فعلی **نمونه** هستند و نشان «نمونه / Sample» دارند. آن‌ها را با موارد واقعی عوض کنید و `sample: true` را حذف کنید.
- هر مورد دو متن دارد: `[فارسی, English]`. دسته‌ی اطلاعیه: `call` / `event` / `news`؛ وضعیت پروژه: `ongoing` / `done`.
- برای لینک، فیلد `link: { href, label }` را اضافه کنید (پروژه‌ها هم همین‌طور).

## زبان / Language
- دکمه‌ی «English / فارسی» در بالای هر صفحه؛ انتخاب کاربر ذخیره می‌شود و با `?lang=en` یا `?lang=fa` هم می‌شود زبان را تعیین کرد.
- ترجمه‌ی متن‌های ثابت در آرایه‌ی `PAIRS` (بخش «دو زبانه» انتهای هر فایل) است: هر ردیف `[فارسی, English]`.
- نام‌های انگلیسی اعضا در فیلد `en` هر عضو در `members.html` است.
